import React, { Component } from 'react';
import DataHOC from './DataHOC';
import ErrorHandlerHOC from './ErrorHandlerHOC';

class HOCDemoTwo extends Component {
    render() {
        return (
            <div>
                <div>
                    <h1 className="text-warning">Higher Order Component Demo Two</h1>
                    <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
                </div>
            </div>
        );
    }
}

export default ErrorHandlerHOC(DataHOC(HOCDemoTwo));