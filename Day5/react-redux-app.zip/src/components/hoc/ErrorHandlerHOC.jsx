import { Component } from "react";

const ErrorHandlerHOC = (InputComponent) => (
    class extends Component {
        constructor(props) {
            super(props);
            this.state = { hasError: false };
        }

        static getDerivedStateFromError(error) {
            return { hasError: true };
        }

        render() {
            if (this.state.hasError)
                return <h2 className="text-danger mt-5">Error, please Refresh</h2>
            else
                return <InputComponent {...this.props} {...this.state} />;
        }
    }
);

export default ErrorHandlerHOC;