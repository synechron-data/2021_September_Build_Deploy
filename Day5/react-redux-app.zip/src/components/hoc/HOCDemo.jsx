import React, { Component } from 'react';
import clockHOC from './ClockHOC';
import DataHOC from './DataHOC';
import ErrorHandlerHOC from './ErrorHandlerHOC';

class HOCDemo extends Component {
    render() {
        // throw new Error("Just for fun");
        return (
            <div>
                <h1 className="text-info">Higher Order Component Demo</h1>
                <h2 className="text-success">Some Data, added by HOC: {this.props.data}</h2>
            </div>
        );
    }
}

export default clockHOC(ErrorHandlerHOC(DataHOC(HOCDemo)));

// const EnhancedComponent = DataHOC(HOCDemo);
// export default EnhancedComponent;

// export default HOCDemo;