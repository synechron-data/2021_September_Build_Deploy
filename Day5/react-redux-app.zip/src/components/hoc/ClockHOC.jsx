import { Component } from "react";

const clockHOC = (InputComponent) => (
    class extends Component {
        constructor(props) {
            super(props);
            this.state = { currentTime: new Date().toLocaleTimeString() };
        }

        componentDidMount() {
            setInterval(() => {
                this.setState({ currentTime: new Date().toLocaleTimeString() });
            }, 1000);
        }

        render() {
            return (
                <>
                    <div className="lead text-right font-weight-bold text-primary">
                        {this.state.currentTime}
                    </div>
                    <InputComponent {...this.props} {...this.state} />
                </>
            )
        }
    }
);

export default clockHOC;