import React, { Component } from 'react';
import PropTypes from 'prop-types';

// const ListItem = ({ item }) => <li className="list-group-item">{item.name}</li>

const ListComponent = (props) => {
    console.log(props);
    return (
        <div>
            {props.children ? props.children : null}
            {/* <ul className="list-group">
                {
                    props.items.map((item, index) => {
                        return <ListItem item={item} key={index} />
                    })
                }
            </ul> */}
            <table className="table">
                <thead>
                    <tr>
                        <th>
                            ID
                        </th>
                        <th>
                            NAME
                        </th>
                    </tr>
                </thead>
                <tbody>
                    {
                        props.items.map((item, index) => {
                            return (
                                <tr key={index}>
                                    <td>{item.id}</td>
                                    <td>{item.name}</td>
                                </tr>
                            );
                        })
                    }
                </tbody>
            </table>
        </div>
    );
};

ListComponent.propTypes = {
    items: PropTypes.arrayOf(PropTypes.object).isRequired
};

class ListRoot extends Component {
    constructor(props) {
        super(props);
        this.state = {
            employees: [
                { id: 1, name: "Manish" },
                { id: 2, name: "Abhijeet" },
                { id: 3, name: "Ramakant" },
                { id: 4, name: "Subodh" },
                { id: 5, name: "Abhishek" }
            ]
        };
    }

    render() {
        return (
            <div>
                <ListComponent items={this.state.employees}>
                    <h1 className="text-primary">
                        Employees List
                    </h1>
                </ListComponent>
            </div>
        );
    }
}

export default ListRoot;