import React, { Component } from 'react';
import PropTypes from 'prop-types';

// Default Value for Props
// class DemoComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h2 className="text-info">Hello, {this.props.name}</h2>
//                 <h2 className="text-info">Age, {this.props.age}</h2>
//             </div>
//         );
//     }

//     static get defaultProps() {
//         return {
//             name: "No Name",
//             age: 0
//         };
//     }
// }

// Validate Props
// npm i prop-types
class DemoComponent extends Component {
    render() {
        return (
            <div>
                <h2 className="text-info">Hello, {this.props.name}</h2>
                <h2 className="text-info">Age, {this.props.age}</h2>
            </div>
        );
    }

    static get propTypes() {
        return {
            name: PropTypes.string.isRequired,
            age: PropTypes.number.isRequired
        };
    }
}

const PropTypesComponent = () => {
    return (
        <div>
            {/* <DemoComponent />
            <hr />
            <DemoComponent name={"Manish"} />
            <hr />
            <DemoComponent name={"Manish"} age={10} /> */}

            {/* <DemoComponent name={10} age={"Hello"} /> */}
            <DemoComponent name={"Manish"} age={10} />
            {/* <DemoComponent /> */}

        </div>
    );
};

export default PropTypesComponent;