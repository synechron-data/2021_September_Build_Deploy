import React, { Component } from 'react';

class ChildComponent extends Component {
    render() {
        return (
            <div>
                <hr />
                <h3 className="text-success">Child Component</h3>
                <h3 className="text-success">Count : {this.props.cnt}</h3>
            </div>
        );
    }
}

class ComponentWithBehaviour extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 1, count: 0 };
    }

    // If you want to access this, you must bind the context
    handleClick() {
        // alert("Clicked....");
        // console.log(this);

        // If you want the UI to be in sync with current state,
        // Do not mutate state directly. Use setState()
        // this.state.count += 1;
        // console.log(this.state);

        // setState() is an Async Function
        // this.setState({ count: this.state.count + 1 });
        // console.log(this.state);

        // If you want to perform any operation after the state changes,
        // put the code in the callback function
        this.setState({ count: this.state.count + 1 }, () => {
            console.log(this.state);
        });
    }

    render() {
        return (
            <div>
                <h2 className="text-info">Component with Behavior</h2>
                <h2 className="text-info">Id: {this.state.id}</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click Me</button>
                <ChildComponent cnt={this.state.count} />
            </div>
        );
    }
}

export default ComponentWithBehaviour;