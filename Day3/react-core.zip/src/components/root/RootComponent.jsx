/* eslint-disable */
import React from 'react';

// import ComponentOne from '../2_multi-components/ComponentOne';
// import ComponentTwo from '../2_multi-components/ComponentTwo';

// import ComponentOne from '../3_component-with-css/ComponentOne';
// import ComponentTwo from '../3_component-with-css/ComponentTwo';

// import ComponentOne from '../4_external-css/comp-one/ComponentOne';
// import ComponentTwo from '../4_external-css/comp-two/ComponentTwo';

import ComponentOne from '../5_css-modules/comp-one/ComponentOne';
import ComponentTwo from '../5_css-modules/comp-two/ComponentTwo';
import ComponentWithState from '../6_comp-state/ComponentWithState';
import ComponentWithProps from '../7_comp-props/ComponentWithProps';
import ComponentWithBehaviour from '../8_comp-methods/ComponentWithBehaviour';
import ClassVsFunctionalComponent from '../9_class-vs-function/ClassVsFunctionalComponent';
import LCDemoComponent from '../10_life-cycle-demo/LCDemoComponent';
import EventComponent from '../11_synthetic-event/EventComponent';
import ControlledVsUncontrolledComponent from '../12_controlled-vs-uncontrolled/ControlledVsUncontrolledComponent';
import ListRoot from '../13_list/ListComponent';
import PropTypesComponent from '../14_prop-types/PropTypesComponent';
import CalculatorAssignment from '../15_assignment/CalculatorAssignment';
import CounterAssignment from '../15_assignment/CounterAssignment';

const RootComponent = () => {
    return (
        <div className="container">
            {/* <ComponentOne />
            <ComponentTwo /> */}
            {/* <ComponentWithState /> */}
            {/* <ComponentWithProps id={1} name={"Manish"} address={{ city: "Pune", state: "MH" }}
                display={() => { alert("From Root"); }} /> */}
            {/* <ComponentWithBehaviour /> */}
            {/* <ClassVsFunctionalComponent /> */}
            {/* <LCDemoComponent /> */}
            {/* <EventComponent /> */}
            {/* <ControlledVsUncontrolledComponent /> */}
            {/* <ListRoot /> */}
            {/* <PropTypesComponent /> */}
            <CalculatorAssignment />
            {/* <CounterAssignment /> */}
        </div>
    );
};

export default RootComponent;