import React, { Component } from 'react';

class ComponentWithState extends Component {
    // state = { name: "Manish" };

    constructor() {
        super();

        // State must be initialized in the constructor
        // State must be set to an object or null
        this.state = { name: "Synechron" };
        console.log("Ctor, State", this.state);
    }

    render() {
        console.log("Render, State", this.state);
        return (
            <div>
                <h2 className="text-info">Component With State</h2>
                <h2 className="text-info">Hello, {this.state.name}</h2>
            </div>
        );
    }
}

export default ComponentWithState;