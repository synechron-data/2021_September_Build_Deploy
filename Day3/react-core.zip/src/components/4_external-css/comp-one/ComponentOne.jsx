import React from 'react';

import './ComponentOne.css';

const ComponentOne = () => {
    return (
        <>
            <h2 className="text-primary">Hello from Component One</h2>
            <h2 className="card1">From Component One</h2>
        </>
    );
};

export default ComponentOne;