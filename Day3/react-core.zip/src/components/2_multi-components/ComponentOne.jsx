import React from 'react';

const ComponentOne = () => {
    return (
        <h2 className="text-primary">
            Hello from Component One
        </h2>
    );
};

export default ComponentOne;