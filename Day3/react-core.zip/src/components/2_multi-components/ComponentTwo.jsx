import React from 'react';

const ComponentTwo = () => {
    return (
        <h2 className="text-success">
            Hello from Component Two
        </h2>
    );
};

export default ComponentTwo;