import React from 'react';
import { NavLink } from 'react-router-dom';

import SwitchComponent from '../../routes';

import './NavigationComponent.css';

var logo = require('../../logo.svg').default;

const NavigationComponent = () => {
    return (
        <>
            <nav className="navbar navbar-expand-sm bg-secondary navbar-dark fixed-top">
                <NavLink className="navbar-brand" to="/">
                    <img src={logo} alt="Angular" width="30" height="30" className="d-inline-block align-top" />
                    React Routing
                </NavLink>
                <button className="navbar-toggler" type="button" data-toggle="collapse"
                    data-target="#navbarText" aria-controls="navbarText"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarText">
                    <ul className="navbar-nav mr-auto">
                        <li className="nav-item px-3">
                            <NavLink exact className="nav-link" to="/">Home</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/about">About</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/products">Products</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/admin">Admin</NavLink>
                        </li>
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/assign">Assignment</NavLink>
                        </li>
                    </ul>
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item px-3">
                            <NavLink className="nav-link" to="/signup">
                                SignUp
                            </NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link" to="/login">
                                Login
                            </NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link logout" to="/login">
                                Logout
                            </NavLink>
                        </li>
                    </ul>
                </div>
            </nav>

            <>
                {SwitchComponent}
            </>
        </>
    );
};

export default NavigationComponent;