/* eslint-disable */
import React from 'react';
import CRUD_Assignment from '../assignment/CRUD_Assignment';
import CounterAssignment from '../assignment/CounterAssignment';
import AjaxComponent from '../1_ajax/AjaxComponent';
import ErrorHandler from '../common/ErrorHandler';
import ContextAPIDemo from '../2_context-api/ContextAPIDemo';
import SiblingCommunicationUsingContext from '../2_context-api/SiblingCommunication';
import HooksDemo from '../3_hooks/HooksDemo';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <CRUD_Assignment /> */}
                {/* <CounterAssignment /> */}
                {/* <AjaxComponent /> */}
                {/* <ContextAPIDemo /> */}
                <SiblingCommunicationUsingContext />
                {/* <HooksDemo /> */}
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;