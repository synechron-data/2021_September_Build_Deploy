import postApiClient from "./post-api-client";

var ajaxDiv = document.getElementById("ajaxDiv");

if (ajaxDiv.style.display === "none") {
    ajaxDiv.style.display = "block";
}

var button = document.createElement("button");
button.className = "btn btn-primary";
button.innerHTML = "Get Data";

var btnArea = document.getElementById("btnArea");
btnArea.appendChild(button);

// 1. Using Callbacks
// button.addEventListener("click", function () {
//     postApiClient.getAllPosts((result) => {
//         generateTable(result);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// 2. Using Promise
// button.addEventListener("click", function () {
//     let promise = postApiClient.getAllPostsUsingPromise();

//     promise.then((result) => {
//         generateTable(result);
//     }).catch((eMsg) => {
//         console.error(eMsg);
//     });
// });

// 3. Using async await 
// button.addEventListener("click", async function () {
//     try {
//         let result = await postApiClient.getAllPostsUsingPromise();
//         generateTable(result);
//     } catch(eMsg) {
//         console.error(eMsg);
//     }
// });

// 4. Using async function 
// button.addEventListener("click", async function () {
//     try {
//         let result = await postApiClient.getAllPostsAsync();
//         generateTable(result);
//     } catch (eMsg) {
//         console.error(eMsg);
//     }
// });

// 5. Using Async Generator function 
button.addEventListener("click", function () {
    const it = postApiClient.getPosts();

    it.next().then(({ value, done }) => {
        generateTable(value);
    }).catch((eMsg) => {
        console.error(eMsg);
    });
});

function generateTable(data) {
    let table = document.getElementById("postTable");
    let row, cell;

    for (let i = 0; i < data.length; i++) {
        row = table.insertRow();
        cell = row.insertCell();
        cell.textContent = data[i].id;
        cell = row.insertCell();
        cell.textContent = data[i].title;
        cell = row.insertCell();
        cell.textContent = data[i].body;
    }
}