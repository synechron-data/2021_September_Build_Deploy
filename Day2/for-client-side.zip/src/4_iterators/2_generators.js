// function* idGenerator() {
//     yield 1;
//     yield 2;
//     yield 3;
//     console.log("Last Line of Generator Function");
// }

// let seq = idGenerator();
// // console.log(seq);

// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());
// console.log(seq.next());

// -----------------------------------

// class Queue {
//     constructor() {
//         this._dataArray = [];
//     }

//     push(data) {
//         this._dataArray.push(data);
//     }

//     pop() {
//         return this._dataArray.shift();
//     }

//     *[Symbol.iterator]() {
//         for(let i=0; i< this._dataArray.length;i++){
//             yield this._dataArray[i];
//         }   
//     }
// }

class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    *[Symbol.iterator]() {
        yield* this._dataArray;
    }
}

let numbersQ = new Queue();
numbersQ.push(10);
numbersQ.push(20);
numbersQ.push(30);

for (const n of numbersQ) {
    console.log(n);
}