'use strict'

// function test1() {
//     console.log(this);
// }

// const test2 = function () {
//     console.log(this);
// }

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const test3 = () => {
//     console.log(this);
// }

// test1();
// test2();

// console.log("Outside all functions:", this);
// test3();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// p1.test();

// -------------------------------------------------

// var p1 = {
//     id: 1
// };

// // function Check(x, y) {
// //     console.log(x, y);
// //     console.log(this);
// // }

// // const Check = function (x, y) {
// //     console.log(x, y);
// //     console.log(this);
// // }

// // In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const Check = (x, y) => {
//     console.log(x, y);
//     console.log(this);
// }

// Check(2, 3);
// Check.call(p1, 2, 3);
// Check.apply(p1, [2, 3]);

// -------------------------------------------------

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

// const display = function () {
//     console.log(JSON.stringify(this));
// };

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// // display.call(p1);
// // display.call(p2);

// p1.display = display.bind(p1);
// p2.display = display.bind(p2);

// p1.display();
// p2.display();

// -------------------------------------------------------------

// function Person(age) {
//     this.age = age;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);

// p1.growOld();
// console.log(p1.age);

// ----------------------------------------------------------------------
//  In ECMASCRIPT ‘this’ refers to the parent of the function and the object through which the function was invoked

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// var p1 = new Person(20);
// document.getElementById("b1").addEventListener("click", p1.growOld);

// ---------------------------------------------------------------------- bind()

// var p1 = new Person(20);

// setInterval(p1.growOld.bind(p1), 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ---------------------------------------------------------------------- Using Lexical Scoping
// function Person(age) {
//     var self = this;

//     self.age = age;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ---------------------------------------------------------------------- Using Arrow Fn
// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.

function Person(age) {
    this.age = age;

    this.growOld = () => {
        this.age += 1;
    }
}

var p1 = new Person(20);

setInterval(p1.growOld, 2000);

setInterval(function () {
    console.log(p1.age);
}, 2000);
