var employees = ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];

function filter(dataArr, x) {
    var result = [];

    for (const item of dataArr) {
        if (item.startsWith(x))
            result.push(item);
    }

    return result;
}

var result1 = filter(employees, 'A');
console.log(result1);                   // ["Akshay"];

var result2 = filter(employees, 'B');
console.log(result2);                   // ["Basavaraj", "Bhavya", "Bibhu"];

var result3 = filter(employees, 'C');
console.log(result3);                   // ["Chethan", "Chhavi"];

console.log(employees);                 // ["Akshay", "Basavaraj", "Bhavya", "Bibhu", "Chethan", "Chhavi"];