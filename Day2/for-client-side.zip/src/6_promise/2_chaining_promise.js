var firstMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ data: 'From first method' });
        }, 2000);
    });
    return promise;
};

var secondMethod = function (someData) {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('second method completed');
            resolve({ newData: someData.data + ', added from second method' });
        }, 2000);
    });
    return promise;
};

var thirdMethod = function (someData) {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('third method completed');
            resolve({ result: someData.newData + ', added from third method' });
        }, 3000);
    });
    return promise;
};

firstMethod().then(secondMethod).then(thirdMethod).then(data => {
    console.log(data);
});