// const Person = (function () {
//     function Person(name) {
//         this._name = name;
//     }

//     Object.defineProperty(Person.prototype, "Name", {
//         get: function () {
//             return this._name;
//         },
//         set: function (value) {
//             this._name = value;
//         }
//     });

//     return Person;
// })();

// var p1 = new Person("Manish");
// console.log(p1.Name);
// p1.Name = "Abhijeet";
// console.log(p1.Name);

// ------------------------------------------------------------------------- ECMASCRIPT 2015

class Person {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }
}

var p1 = new Person("Manish");
console.log(p1.Name);
p1.Name = "Abhijeet";
console.log(p1.Name);