// // Declaration Syntax - Is Hosited
// function hello1() {
//     console.log("Hello 1 from JavaScript Function");
// }

// hello1();

// // Expression Syntax - Is not Hosited
// const hello2 = function () {
//     console.log("Hello 2 from JavaScript Function");
// }

// hello2();

// // Contructor Syntax - Is not Hosited
// const hello3 = new Function('console.log("Hello 3 from JavaScript Function")');
// hello3();

// // ECMASCRIPT 2015 - Arrow Function Syntax - Is not Hosited
// const hello4 = () => {
//     console.log("Hello 4 from JavaScript Function");
// }

// hello4();

// --------------------------------------------------------

var i = 10;
console.log("i is: ", i);
console.log("Type of i is: ", typeof i);

var f = function () {
    console.log("Hello");
};
console.log("f is: ", f);
console.log("Type of f is: ", typeof f);

// Can we create a variable of type number?
// If yes; We should be able to create a variable of type function also

// Can we create a variable of type number inside a function?
// If yes; We should be able to create a variable of type function inside a function also (Nested Function)

// Can we return a variable of type number from a function?
// If yes; We should be able to return a variable of type function from a function also (Closures/Currying/HOF)

// Can we pass a variable of type number to a function?
// If yes; We should be able to pass a variable of type function to a function also (Callbacks)