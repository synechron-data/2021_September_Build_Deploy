'use strict'

// var count = 0;

// function next() {
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// count = "Hello";
// console.log(next());

// -------------------------------------

// function next() {
//     var count = 0;
//     return count += 1;
// }

// console.log(next());
// console.log(next());
// console.log(next());

// -------------------------------------

// function getNext() {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     return next;
// }

// const next = getNext();

// console.log(next());
// console.log(next());
// console.log(next());

// -------------------------------------

// const next = (function () {
//     var count = 0;

//     return function next() {
//         return count += 1;
//     }
// })();

// console.log(next());
// console.log(next());
// console.log(next());

// -------------------------------------

// const counter = (function () {
//     var count = 0;

//     function next() {
//         return count += 1;
//     }

//     function prev() {
//         return count -= 1;
//     }

//     return {
//         next: next,
//         prev: prev
//     };
// })();

// ECMASCRIPT 2015 - Object Literal Improvement
const counter = (function () {
    var count = 0;

    function next() {
        return count += 1;
    }

    function prev() {
        return count -= 1;
    }

    return { next, prev };
})();

console.log(counter.next());
console.log(counter.next());
console.log(counter.prev());
console.log(counter.prev());