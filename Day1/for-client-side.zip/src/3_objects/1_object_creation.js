// var obj1 = null;
// console.log("obj1: ", obj1);
// console.log("Type of obj1 is: ", typeof obj1);

// var obj2 = new Object();
// console.log("obj2: ", obj2);
// console.log("Type of obj2 is: ", typeof obj2);

// // Object Literal Syntax
// var obj3 = {};
// console.log("obj3: ", obj3);
// console.log("Type of obj3 is: ", typeof obj3);

// JavaScript Value/Object
var person = {
    id: 1,
    name: "Manish",
    address: {
        city: "Pune",
        state: "MH"
    },
    display: function() {
        console.log(this);
    }
};

console.log(person);
console.log(typeof person);

// Converts a JavaScript value to a JavaScript Object Notation (JSON) string.
var person_JSON = JSON.stringify(person);
console.log(person_JSON);
console.log(typeof person_JSON);

// Converts a JavaScript Object Notation (JSON) string into an object.
var person1 = JSON.parse(person_JSON);
console.log(person1);
console.log(typeof person1);
