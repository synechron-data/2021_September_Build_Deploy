// Import an entire module for side effects only, without importing anything. 
// This runs the module's global code, but doesn't actually import any values.

// import './1_datatypes/1_declarations';
// import './1_datatypes/2_es6-declartions';
// import './1_datatypes/3_es6-const';
// import './1_datatypes/4_datatypes';
// import './1_datatypes/5_symbol';
// import './1_datatypes/6_query';

// import './2_functions/1_fn_creation';
// import './2_functions/2_fn_parameters';
// import './2_functions/3_rest_and_spread';
// import './2_functions/4_pure_impure_fn';
import './2_functions/5_closure';

// import './3_objects/1_object_creation';