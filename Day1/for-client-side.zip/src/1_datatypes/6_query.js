let a = 10;

function test() {
    let a = 100;

    if (true) {
        let a = 1000;
        console.log("Inside block(), a is: ", a);
    }

    console.log("Inside test(), a is: ", a);
}

test();
console.log("Outside test(), a is: ", a);