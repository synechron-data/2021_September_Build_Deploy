// var result = 10 * true;
// var result = 10 * "abc";
// console.log(result);

// console.log(true && "abc");
// console.log(true && true);
// console.log(true && false);

// console.log(true && "abc" || "xyz");
// console.log(false && "abc" || "xyz");

// console.log(true ? "abc" : "xyz");
// console.log(false ? "abc" : "xyz");

// var obj = null;
// // // var obj = { id: 1 };

// // if ((obj == null) || (obj == undefined)) {
// //     console.log("object is null or undefined");
// // } else {
// //     console.log("object is: ", obj);
// // }

// if (!obj) {
//     console.log("object is null or undefined");
// } else {
//     console.log("object is: ", obj);
// }

// ----------------------------------------------
// var a = 10;
// var b = "10";

// console.log(typeof a);
// console.log(typeof b);

// console.log(a == b);      // Abstract Equality
// console.log(a === b);      // Strict Equality

// ----------------------------------------------
// var a = { id: 10 };
// var b = { id: 10 };
// var c = b;

// console.log(typeof a);
// console.log(typeof b);

// // console.log(a == b);       // Abstract Equality
// // console.log(a === b);      // Strict Equality

// console.log(b == c);       // Abstract Equality
// console.log(b === c);      // Strict Equality

// --------------------------------------------------------------------------------

// const color = "red";

// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor("red");

// var clr = "red";
// isRedColor(clr);

// ---------------------------------

// const color = { clr: "red" };

// function isRedColor(str) {
//     console.log(str === color);
// }

// isRedColor(color);
// isRedColor({ clr: "red" });

// var clr = { clr: "red" };
// isRedColor(clr);

// ------------------------------------------------- ECMASCRIPT 2015 - Symbol (Unique Immutables)

const color = Symbol("red");

function isRedColor(str) {
    console.log(str === color);
}

isRedColor(color);
isRedColor(Symbol("red"));

var clr = Symbol("red");
isRedColor(clr);